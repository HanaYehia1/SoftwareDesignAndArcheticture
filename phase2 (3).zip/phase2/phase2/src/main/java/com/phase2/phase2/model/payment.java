package com.phase2.phase2.model;

public interface payment {
	public double cost(service s);
}
