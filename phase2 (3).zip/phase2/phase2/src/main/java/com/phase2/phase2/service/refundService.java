package com.phase2.phase2.service;

import java.util.ArrayList;

import com.phase2.phase2.model.transaction;

public class refundService {
	
	
	public boolean checkRefundRequest(String name)
	{
		boolean checkRefundRequest=false;
		if(payService.t.size()>0)
	      {
		       for(int i=0;i<payService.t.size();i++)
	              {
		            if(name.equalsIgnoreCase(payService.t.get(i).getUsernamr())&&payService.t.get(i).getTypetransaction().equalsIgnoreCase("payment"))
		              {
	                     System.out.println(" index: "+i+" "+payService.t.get(i).getService().toString()+"" +" amount of transaction is "+ payService.t.get(i).getAmount()+payService.t.get(i).getTypetransaction());
	                     checkRefundRequest=true;
		              }
	              }
	     }
		if(checkRefundRequest==true)
		  {
			return true;
		  }
		System.out.println("You didn't make a transaction to make a refund!!!");
		return false;	
	}
	
	public void applyRefundRequest(int index,String name)

	{
		payService.refundList.add(new transaction(payService.t.get(index).getAmount(),payService.t.get(index).getService(),"Waiting for acceptance", name,index));
		System.out.println("Request added succesfully ");
	}
	
	public ArrayList<String> DisplayListOFrefunds()
	{
		ArrayList<String> list=new ArrayList<String>();
		String st;
		for(int i=0;i<payService.refundList.size();i++)
		{
			if(payService.refundList.get(i).getTypetransaction().equalsIgnoreCase("Waiting for acceptance"))
		    System.out.println("Amount= "+payService.refundList.get(i).getAmount()+" "+"service name:"+payService.refundList.get(i).getService().toString()+" index"+i);
			st="Amount= "+payService.refundList.get(i).getAmount()+" "+"service name:"+payService.refundList.get(i).getService().toString()+" index"+i;
		    list.add(st);
		}
		return list;
	}
	public boolean HandelRefundrequest(int index ,int choice)
	{
		if(payService.refundList.size()>0)
		{
		    if(choice==1)
		      {
			    payService.refundList.get(index).setTransactionStatus("accepted");
			    return true;
		      }
		    else
		    {
			  payService.refundList.get(index).setTransactionStatus("not accepted");
		      return false;
		    }
	      }
		return true;
	}

	public ArrayList<String> ShowListOfRefunds(String name) //show list of refund 
	{
		ArrayList<String> list=new ArrayList<String>();
		int counter=0;
		String st;
		if(payService.refundList.size()>0)
		{
			for(int i=0;i<payService.refundList.size();i++)
			{
				if(name.equalsIgnoreCase(payService.refundList.get(i).getUsernamr()))
				{
					System.out.println("refunds requests: "+" "+payService.refundList.get(i).getAmount()+" Amount "+payService.refundList.get(i).getService()+ ", Status: "+payService.refundList.get(i).getTypetransaction());
					st="refunds requests: "+" "+payService.refundList.get(i).getAmount()+" Amount "+payService.refundList.get(i).getService()+ ", Status: "+payService.refundList.get(i).getTypetransaction();
					list.add(st);
					counter++;
				}
				
			}
		}
		
		 if(payService.refundList.size()==0&& counter==0)
			System.out.println("No refunds requests");
		
		 if(counter==0)
			System.out.println("No refunds requests");
			
		 return list;
	}
	
	public boolean requestRefund(String name,int index)
	{

		if(checkRefundRequest(name)==true)
		{
			applyRefundRequest(index,name);
			return true;
		}
		else
			return false;
	}
	 
}
