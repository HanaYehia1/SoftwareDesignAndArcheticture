package com.phase2.phase2.model;



public class creditCard implements payment{
@Override
public double cost(service s) {
		
		if(s.supportsCashOnDelivery()) {
			return s.getCost();
		}
		else {
			System.out.println("This service doesn't support credit card");
			return 0;
		}
	}
}
