package com.phase2.phase2.service;

import java.util.ArrayList;

import com.phase2.phase2.contoller.controller;
import com.phase2.phase2.model.creditCard;
import com.phase2.phase2.model.donationService;
import com.phase2.phase2.model.form;
import com.phase2.phase2.model.internetPaymentService;
import com.phase2.phase2.model.landlineService;
import com.phase2.phase2.model.mobileRechargeService;
import com.phase2.phase2.model.overallDiscount;
import com.phase2.phase2.model.payment;
import com.phase2.phase2.model.service;
import com.phase2.phase2.model.specificDiscount;
import com.phase2.phase2.model.transaction;
import com.phase2.phase2.serviceproviders.cancerHospitals;
import com.phase2.phase2.serviceproviders.donationsServiceProvider;
import com.phase2.phase2.serviceproviders.etisalatIS;
import com.phase2.phase2.serviceproviders.etisalatMS;
import com.phase2.phase2.serviceproviders.internetServiceProvider;
import com.phase2.phase2.serviceproviders.landlineServiceProvider;
import com.phase2.phase2.serviceproviders.mobileServiceProvider;
import com.phase2.phase2.serviceproviders.monthlyReceipt;
import com.phase2.phase2.serviceproviders.ngo;
import com.phase2.phase2.serviceproviders.orangeIS;
import com.phase2.phase2.serviceproviders.orangeMS;
import com.phase2.phase2.serviceproviders.quarterReceipt;
import com.phase2.phase2.serviceproviders.schools;
import com.phase2.phase2.serviceproviders.vodafoneIS;
import com.phase2.phase2.serviceproviders.vodafoneM;
import com.phase2.phase2.serviceproviders.weIS;
import com.phase2.phase2.serviceproviders.weMS;


public class payService {

	public static ArrayList<transaction>refundList=new ArrayList<>();
    public 	static ArrayList<transaction>t=new ArrayList<>();
	double value;
	refundService r=new refundService();
	
	public ArrayList<String> usertransaction(String username)  //show user transaction
	{
		ArrayList<String> s=new ArrayList<>();
		String st;
		    System.out.println(t.size());
		    for(int i=0;i<t.size();i++)
		       {
			
			       if(username.equalsIgnoreCase(t.get(i).getUsernamr()))
			          {
				        if(t.get(i).getTypetransaction().equalsIgnoreCase("payment"))
				        {
				        	st=" mobile number= "+t.get(i).getTyepe()+" "+t.get(i).getService().toString()+" "+t.get(i).getTypetransaction() +" amount of transaction is"+ t.get(i).getAmount();
				        	System.out.println(" mobile number= "+t.get(i).getTyepe()+" "+t.get(i).getService().toString()+" "+t.get(i).getTypetransaction() +" amount of transaction is "+ t.get(i).getAmount());
				            s.add(st);
				        }
				        
				        if(t.get(i).getTypetransaction().equalsIgnoreCase("add to wallet"))
				        {
				        	st=" "+t.get(i).getTypetransaction() +" amount of transaction is "+ t.get(i).getAmount();
					        System.out.println(" "+t.get(i).getTypetransaction() +" amount of transaction is  "+ t.get(i).getAmount());	
					        s.add(st);
				        }
			          }	
		       }		  
		    s.addAll(r.ShowListOfRefunds(username));
		    r.ShowListOfRefunds(username);
		return s;
	}

public boolean  createUsertransactionPay(int num,double amount, service serviceName,String names)
{
	t.add(new transaction(num,amount,serviceName,"payment",names));	
    return true;
}
public void createUsertransactionWallet(int num,double amount, service serviceName,String names)
{
		
	t.add(new transaction(num,amount,null,"add to wallet",names));	
	
}
public service getObj(String serviceName)
{
	if(serviceName.equalsIgnoreCase("mobile"))
	{
		return new mobileRechargeService();
	}
	else if(serviceName.equalsIgnoreCase("internet"))
	{
		return new internetPaymentService();
	}
	else if(serviceName.equalsIgnoreCase("landline"))
	{
		return new landlineService();
	}
	else if(serviceName.equalsIgnoreCase("donations"))
	{
		return new donationService();
	}
	else
	return null;
}

public mobileServiceProvider returnMprovider(String prov)
{
	if(prov.equalsIgnoreCase("etisalat"))
	{
		return new etisalatMS();
	}
	else if(prov.equalsIgnoreCase("orange"))
	{
		return new orangeMS();
	}
	else if(prov.equalsIgnoreCase("vodafone"))
	{
		return new vodafoneM();
	}
	else if(prov.equalsIgnoreCase("we"))
	{
		return new weMS();
	}
	else return null;
}
public internetServiceProvider returnIprovider(String provi)
{
	if(provi.equalsIgnoreCase("etisalat"))
	{
		return new etisalatIS();
	}
	else if(provi.equalsIgnoreCase("orange"))
	{
		return new orangeIS();
	}
	else if(provi.equalsIgnoreCase("vodafone"))
	{
		return new vodafoneIS();
	}
	else if(provi.equalsIgnoreCase("we"))
	{
		return new weIS();
	}
	else return null;
}

public landlineServiceProvider returnLprovider(String provid)
{
	if(provid.equalsIgnoreCase("monthlyReceipt"))
	{
		return new monthlyReceipt();
	}
	else if(provid.equalsIgnoreCase("quarterReceipt"))
	{
		return new quarterReceipt();
	}
	else return null;
}
public donationsServiceProvider returnDprovider(String provider)
{
	if(provider.equalsIgnoreCase("schools"))
	{
		return new schools();
	}
	else if(provider.equalsIgnoreCase("ngo"))
	{
		return new ngo();
	}
	else if(provider.equalsIgnoreCase("cancerHospitals"))
	{
		return new cancerHospitals();
	}
	else return null;
}
public boolean pay(String servicename,String provider,form f,int number,double amount,String names,boolean checkuser)
{
	service ser= getObj(servicename);
    payment overall=new overallDiscount(new creditCard());
    payment spec=new specificDiscount(new creditCard());
    

	if(servicename.equalsIgnoreCase("mobile"))
	{
		mobileServiceProvider MSP= returnMprovider(provider);
        MSP.createForm(f, ser, number, amount);
        amount=totalmoney(overall, spec, ser,checkuser);
        createUsertransactionPay(number, amount, ser,names);
		return true;
	}
	else if(servicename.equalsIgnoreCase("internet"))
	{
		internetServiceProvider ISP= returnIprovider(provider);
		ISP.createForm(f, ser, number, amount);
		amount=totalmoney(overall, spec, ser,checkuser);
		createUsertransactionPay(number, amount, ser, names);
		return true;
	}
	else if(servicename.equalsIgnoreCase("landline"))
	{
		landlineServiceProvider LSP= returnLprovider(provider);
		LSP.createForm(f, ser, number, amount);
		amount=totalmoney(overall, spec, ser,checkuser);
		createUsertransactionPay(number, amount, ser, names);
		return true;
	}
	else if(servicename.equalsIgnoreCase("donations"))
	{
		donationsServiceProvider DSP =returnDprovider(provider);
		DSP.createForm(f, ser, number, amount);
		amount=totalmoney(overall, spec, ser,checkuser);
		createUsertransactionPay(number, amount, ser,names);
		return true;
	}
	return false;
}

public double totalmoney(payment overall,payment specific, service serviceName,boolean check)  
{
	 
	 double discountvalue;
	 if(check==false) 
	 {
	 double overalldis=overall.cost(serviceName);
	 double specificdis=specific.cost(serviceName);
	 discountvalue=overalldis-(serviceName.getCost()-specificdis);
	 System.out.println(serviceName.getCost());
	 System.out.println(discountvalue);
	 return discountvalue;
	
	 }
	 else 
	 {
		// payment spec=new specificDiscount(new creditCard());
		 discountvalue=specific.cost(serviceName);
		 System.out.println(serviceName.getCost());
		 System.out.println(discountvalue);
		 return discountvalue;
	 }
	 
}


}
