package com.phase2.phase2.model;

import java.util.ArrayList;

public class adminEntity {


	public static ArrayList<Double>SDlist1=new ArrayList<>();
	public static ArrayList<service>SDlist2=new ArrayList<>();
	public static ArrayList<Double>overallList=new ArrayList<>();
	
}
