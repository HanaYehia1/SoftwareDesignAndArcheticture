package com.phase2.phase2.model;

public abstract class field {

	public form form;
	
	field(form form)
	{
		this.form = form;
	}
	field(){}
	public abstract void execute(double cost);
	public abstract double getInfo();
}