package com.phase2.phase2.model;

import com.phase2.phase2.service.discountImp;

public class overallDiscount extends paymentDecorator{


	public discountImp ad=new discountImp();
	public overallDiscount(payment pay) 
	{
		super(pay);
	}
	
	public double cost(service c) 
	{
		if(ad.getdiscountpr("overall",null)==1)
			return super.cost(c);
		else 
			return ((100-ad.getdiscountpr("overall",null))/100)*super.cost(c);
		
	}

}
