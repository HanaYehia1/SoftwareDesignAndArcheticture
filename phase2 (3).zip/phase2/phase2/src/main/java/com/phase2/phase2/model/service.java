package com.phase2.phase2.model;

public abstract class service {

	public abstract void setCost(double cost);
	public abstract double getCost();
	public  abstract boolean supportsCashOnDelivery() ;
	
}
