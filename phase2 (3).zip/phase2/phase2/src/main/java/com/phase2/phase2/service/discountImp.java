package com.phase2.phase2.service;

import java.util.ArrayList;

import com.phase2.phase2.model.adminEntity;
import com.phase2.phase2.model.donationService;
import com.phase2.phase2.model.internetPaymentService;
import com.phase2.phase2.model.landlineService;
import com.phase2.phase2.model.mobileRechargeService;
import com.phase2.phase2.model.service;

public class discountImp {

//	static ArrayList<transaction>refundList=new ArrayList<>();
//	static ArrayList<transaction>t=new ArrayList<>();
	double value;
	
	public boolean addSpecificDiscount(double disvalue,int serviceName)
    { 

        if(serviceName==1) 
        {
           service service = new mobileRechargeService();
           adminEntity.SDlist1.add(disvalue);
           adminEntity.SDlist2.add(service);
           return true;
        }
        else if(serviceName==2) 
        {
            service service = new internetPaymentService();
            adminEntity.SDlist1.add(disvalue);
            adminEntity.SDlist2.add(service);
            return true;
         }
        else if(serviceName==3) 
        {
            service service = new landlineService();
            adminEntity.SDlist1.add(disvalue);
            adminEntity.SDlist2.add(service);
            return true;
            }
        else if(serviceName==4)
        {
            service service = new donationService();
            adminEntity. SDlist1.add(disvalue);
            adminEntity.SDlist2.add(service);
            return true;
            }
        else
        {
        	return false;
        }

    }
	
	public boolean addoverallDiscount(double disvalue)
	{ 
		adminEntity.overallList.add(disvalue);
		System.out.println("discount added successfully ");
		return true;
	}
	
	public double getdiscountpr(String typediscount,service servicename)
	{
		if(typediscount.equalsIgnoreCase("overall"))
		{
			if(adminEntity.overallList.size()!=0)
			     return adminEntity.overallList.get(0);
		}
		else if(typediscount.equalsIgnoreCase("specific"))
		{
			if(adminEntity.SDlist2.size()!=0)
			{
			for(int i=0;i<adminEntity.SDlist1.size() ;i++)
			{
				
				if(adminEntity.SDlist2.get(i).getClass()==servicename.getClass())
				{
					return adminEntity.SDlist1.get(i);
			    }
				
				}
			}
			
		}
		return 1;
	}
	public ArrayList<String> displayDiscount()
	{
		ArrayList<String> discounts = new ArrayList<>();
		//System.out.println("discounts on all services ="+adminEntity.overallList.toString());
		discounts.add(0, adminEntity.overallList.toString());
		for(int i=1;i<=adminEntity.SDlist1.size();i++)
		{
			//System.out.println("specific discount Name"+adminEntity.SDlist2.toString()+"amount"+adminEntity.SDlist1.toString());
			discounts.add(i, adminEntity.SDlist1.toString());
			discounts.add(i, adminEntity.SDlist2.toString());
		}
		return discounts;
	}
}
