package com.phase2.phase2.service;

import java.util.ArrayList;

import com.phase2.phase2.model.mobileRechargeService;
import com.phase2.phase2.model.service;
import com.phase2.phase2.model.transaction;


public class payService {

	public static ArrayList<transaction>refundList=new ArrayList<>();
    public 	static ArrayList<transaction>t=new ArrayList<>();
	double value;
	refundService r=new refundService();
	
	public ArrayList<transaction> usertransaction(String username)  //show user transaction
	{
		ArrayList<transaction> list=new ArrayList<transaction>();
		
		    System.out.println(t.size());
		    for(int i=0;i<t.size();i++)
		       {
			
			       if(username.equalsIgnoreCase(t.get(i).getUsernamr()))
			          {
				        if(t.get(i).getTypetransaction().equalsIgnoreCase("payment"))
				        {
				        	System.out.println(" mobile number= "+t.get(i).getTyepe()+" "+t.get(i).getService().toString()+" "+t.get(i).getTypetransaction() +" amount of transaction is"+ t.get(i).getAmount());
				            list.add(new transaction(t.get(i).getTyepe(),t.get(i).getAmount(),t.get(i).getService(),t.get(i).getTypetransaction()));
				        }
				        
				        if(t.get(i).getTypetransaction().equalsIgnoreCase("add to wallet"))
				        {
					    System.out.println(" "+t.get(i).getTypetransaction() +" amount of transaction is "+ t.get(i).getAmount());	
				        list.add(new transaction(0,t.get(i).getAmount(),null,t.get(i).getTypetransaction()));
				        }
			          }	
		       }
		    list.addAll(r.ShowListOfRefunds(username));
		    r.ShowListOfRefunds(username);
		
		return list;
	}

public void createUsertransactionPay(int num,double amount, service serviceName,String names)
{
	
	t.add(new transaction(num,amount,serviceName,"payment",names));	
}
public void createUsertransactionWallet(int num,double amount, service serviceName,String names)
{
		
	t.add(new transaction(num,amount,null,"add to wallet",names));	
	
}
public service getObj(String serviceName)
{
	if(serviceName.equalsIgnoreCase("mobile"))
	{
		return new mobileRechargeService();
	}
	return null;
}

}
