package com.phase2.phase2.serviceproviders;

import com.phase2.phase2.model.form;
import com.phase2.phase2.model.service;

public abstract class mobileServiceProvider {

	mobileServiceProvider(){}
	public abstract String toString();
	public void display() {
		 System.out.println("Please Enter your Mobile Number");
		 System.out.println("Please Enter The amount to be recharged");   
	}
	public abstract void createForm(form  f,service serviceName,int number,double money);
}
