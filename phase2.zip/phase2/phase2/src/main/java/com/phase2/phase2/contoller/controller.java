package com.phase2.phase2.contoller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.phase2.phase2.model.account;
import com.phase2.phase2.service.discountImp;
import com.phase2.phase2.service.payService;
import com.phase2.phase2.service.refundService;
import com.phase2.phase2.service.serviceImp;
import com.phase2.phase2.service.serviceProducer;
import com.phase2.phase2.model.response;
import com.phase2.phase2.model.transaction;

@RestController
public class controller {
	
	List<account> list = new ArrayList<account>();
	 	discountImp dis = new discountImp();
	    serviceImp Service = new serviceImp();
	    serviceProducer ser = new serviceProducer();
	    refundService s=new refundService();
	    payService p=new payService();
	@PostMapping("/user/signUp")
    public response signUp(@RequestParam("username") String username,@RequestParam("email")String email,@RequestParam("password")String password) 
	{
        boolean res = Service.signUp(username,email,password);
        response response = new response();
        if (!res) {
            response.setStatus(false);
            response.setMessage("account Already Exists");
            return response;
        }

        response.setStatus(true);
        response.setMessage("account created successfully");
        return response;
    }
	@PostMapping("/user/signIn")
	public response sigIn(@RequestParam("email") String email,@RequestParam("password")String password) 
	{
        boolean res = Service.signIn(email,password);
        response response = new response();
        if (!res) {
            response.setStatus(false);
            response.setMessage("Account doesn't exist");
            return response;
        }
        response.setStatus(true);
        response.setMessage("Successfully signed in");
        return response;
    }
	
	@PostMapping("/user/addToWallet")
	public response addToWallet(@RequestParam("username") String username,@RequestParam("amount")double amount,@RequestParam("cardnumber")String cardnumber) 
	{
        boolean res = Service.addtowallet(username, 0, cardnumber);
        response response = new response();
        if (!res) {
            response.setStatus(false);
            response.setMessage("Please check details and try again");
            return response;
        }
        response.setStatus(true);
        response.setMessage("Funds added successfully to wallet");
        p.createUsertransactionWallet(0, amount,null, username);
        return response;
    }
	
	@GetMapping("/user/search")
	public ArrayList<String> search(@RequestParam("s")String s)
	{ 
		ArrayList<String> str=new ArrayList<>();
		str=ser.searchService(s);
	 	return str;
	}
	
	@GetMapping("/user/showDiscount")
	public ArrayList<String> displayDiscount()
	{ 
		ArrayList<String> str=new ArrayList<>();
		str=dis.displayDiscount();
		return str;
	}

	@PostMapping("/user/requestRefund")
	public response refundRequest(@RequestParam("username") String username,@RequestParam("index")int index) 
	{
        boolean res =s.requestRefund(username, index);
        response response = new response();
        if (!res) {
            response.setStatus(false);
            response.setMessage("Please check details and try again");
            return response;
        }
        response.setStatus(true);
        response.setMessage("Funds added successfully to wallet");
        return response;
    }
	
	@GetMapping("/user/showRefundrequest")
	public ArrayList<transaction> ShowRefundRequest(@RequestParam("username")String username)
	{ 
		return s.ShowListOfRefunds(username);
	}


}
