package com.phase2.phase2.contoller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.phase2.phase2.model.response;
import com.phase2.phase2.model.transaction;
import com.phase2.phase2.service.discountImp;
import com.phase2.phase2.service.payService;
import com.phase2.phase2.service.refundService;



@RestController
public class adminController {

	
	public discountImp d=new discountImp(); 
	public payService p=new payService();
	public refundService s=new refundService();
	@PostMapping("/admin/addoverallDiscount")
	 public response addoverallDiscountt(@RequestParam("disvalue")double disvalue) 
		{
	        boolean res = d.addoverallDiscount(disvalue);
	        response response = new response();
	        if (!res) {
	            response.setStatus(false);
	            response.setMessage("Discount doesn't apply ");
	            return response;
	        }

	        response.setStatus(true);
	        response.setMessage("discount added successfully ");
	        return response;
	    }
	@PostMapping("/admin/addspecificDiscount")
	 public response addspecificDiscount(@RequestParam("disvalue")double disvalue,@RequestParam("serviceName")int serviceName) 
		{
	        boolean res = d.addSpecificDiscount(disvalue, serviceName);
	        response response = new response();
	        if (!res) {
	            response.setStatus(false);
	            response.setMessage("Discount doesn't apply on this service ");
	            return response;
	        }

	        response.setStatus(true);
	        response.setMessage("discount added successfully ");
	        return response;
	    }
	
	@GetMapping("/admin/showUserTransactions")
	public ArrayList<transaction> UserTransactions(@RequestParam("username")String username)
	{ 
		return p.usertransaction(username);
	}
	
	@GetMapping("/admin/showRefundList")
	public ArrayList<transaction> ShowRefundList()
	{ 
		return s.DisplayListOFrefunds();
	}
	
	@PostMapping("/admin/handleRefundRequest")
	 public response handleRefundRequest(@RequestParam("index")int index,@RequestParam("choice")int choice) 
		{
	        boolean res = s.HandelRefundrequest(index, choice);
	        response response = new response();
	        if (!res) {
	            response.setStatus(false);
	            response.setMessage("The refund request is denied");
	            return response;
	        }

	        response.setStatus(true);
	        response.setMessage("The refund request is accepted ");
	        return response;
	    }
	
}
