package com.phase2.phase2.serviceproviders;

import com.phase2.phase2.model.dropDownField;
import com.phase2.phase2.model.form;
import com.phase2.phase2.model.service;
import com.phase2.phase2.model.textField;

public class vodafoneM extends mobileServiceProvider{


	public vodafoneM() {
	}

	@Override
	public String toString() {
		 String var="Vodafone Mobile Recharge Service";
         return var;
	}

	@Override
	public void createForm(form f, service serviceName, int number, double money) {
		// TODO Auto-generated method stub
		textField t2 = new textField();
		dropDownField t1= new dropDownField();
		f.Addfields(t2);
		f.Addfields(t1);
		f.getFields().get(0).execute(number);
		f.getFields().get(1).execute(money);
		serviceName.setCost(f.getFields().get(1).getInfo());
		
	}

}
