package com.phase2.phase2.model;

import com.phase2.phase2.service.discountImp;
public class specificDiscount extends paymentDecorator{


	public discountImp ad=new discountImp();

	specificDiscount(payment pay) 
	{
		super(pay);
	}
	
	public double cost(service s) 
	{
		if(ad.getdiscountpr("specific",s)==1)
			return super.cost(s);
		else
			return ((100-ad.getdiscountpr("specific",s))/100)*super.cost(s);
			
	}
}
